import os
import shutil
from py_ext.lzma import listdir_compress_file, decompress


class Params:
    kaggle = False


params = Params()

# 路径
realtime_root = r"D:\通达信录制数据\realtime_data"
his_root_net = r"Z:\L2_DATA\his_data"
his_root = r"D:\code\featrue_data\tdx_a_raw_datas"
kaggle_his_root = r'/kaggle/input/raw-data/tdx_a_datas'
his_binance_root = r"\\192.168.100.203\wd_media\BINANCE_DATA"

# 交易费率
fee_rate = 0.00005
min_fee = 0.01

# 需要的所有code
pre_codes = []


def get_realtime_data_path(date):
    """返回日期对应的实时数据路径 
    date: 20230901
    """
    path = os.path.join(realtime_root + '/ago/data',
                        date) if date < "20230906" else os.path.join(realtime_root, date) + "/data"

    # 检查路径是否存在
    if not os.path.exists(path):
        print(f"实时数据不存在: {path}")

    return path


zip_codes_dict = {}


def pre_his_raw_data(date, code):
    file = f'{date}.7z'

    src = os.path.join(his_root_net, file)
    dst = os.path.join(his_root, file)
    final_folder = dst.replace('.7z', '')

    # 检查 src 中是否有 code 文件夹
    if file not in zip_codes_dict:
        zip_codes = [i.replace(f'/{date}/', '').replace(f'/', '')
                     for i in listdir_compress_file(src, f'/{date}/')]
        zip_codes_dict[file] = zip_codes

    if code not in zip_codes_dict[file]:
        return False

    # 拷贝到his_root
    shutil.copy2(src, dst)

    # 解压文件
    temp_folder = os.path.join(his_root, '_temp')
    if os.path.exists(temp_folder):
        shutil.rmtree(temp_folder)
    decompress(dst, '_temp')

    # 最终文件夹
    os.makedirs(final_folder, exist_ok=True)

    # 遍历拷贝
    temp_folder2 = os.path.join(temp_folder, file.replace('.7z', ''))
    for i in os.listdir(temp_folder2):
        if i in pre_codes:
            # os.makedirs(os.path.join(final_folder, i), exist_ok=True)
            # shutil.copy2(os.path.join(temp_folder2, i, '十档盘口.csv'),
            #              os.path.join(final_folder, i, '十档盘口.csv'))
            shutil.copytree(os.path.join(temp_folder2, i),
                            os.path.join(final_folder, i))

    # 删除临时文件夹
    shutil.rmtree(temp_folder)
    return True


def get_his_data_path(code, date, filename):
    """
    返回日期对应的盘后历史数据路径 
    code: 513050
    date: 20230901
    """
    # 先检查本地目录
    assert params.kaggle == False
    code_path = os.path.join(his_root, date, code)
    file_path = os.path.join(code_path, filename)
    if not os.path.exists(file_path):
        print(f"本地历史数据不存在: {file_path}")

        # 如果code 文件夹存在，则清空（数据不全）
        if os.path.exists(code_path):
            shutil.rmtree(code_path)
        os.makedirs(code_path)

        # 解压缩net目录中的7z文件，储存到本地
        if not pre_his_raw_data(date, code):
            return ''

    return file_path


def get_his_times_binance():
    """返回所有的历史数据毫秒时间戳"""
    # 1708434355772 毫秒时间戳列表
    times_net = [i.replace("trade_", '') for i in os.listdir(
        his_binance_root) if "trade_" in i]

    times = list(set(times_net))
    times.sort()
    return times


def get_his_dates():
    """返回所有的历史数据日期"""
    raw_folder = kaggle_his_root if params.kaggle else his_root_net
    all_dates = [i.split('_')[0] for i in os.listdir(raw_folder) if len(
        i) > 12] if params.kaggle else [i.replace('.7z', '') for i in os.listdir(
            his_root_net) if len(i) == 11 and i[:8].isdigit()]
    all_dates = list(set(all_dates))
    all_dates = sorted(all_dates)

    return all_dates


def get_realtime_dates():
    """返回所有的实时录制数据日期"""
    # 8位 且全是数字
    return [i for i in os.listdir(realtime_root + '/ago/data') + os.listdir(realtime_root) if len(i) == 8 and i.isdigit()]


if __name__ == "__main__":
    his_dates = get_his_dates()
    realtime_dates = get_realtime_dates()
    print(his_dates)
    print(realtime_dates)
