import os

__all__ = ['min_fee', 'fee_rate', "get_realtime_data_path",
           "get_his_data_path", "get_his_times_binance", "get_his_dates", "get_realtime_dates"]

# 路径
realtime_root = r"D:\通达信录制数据\realtime_data"
his_root = r"D:\L2_DATA\his_data"
his_binance_root = r"\\192.168.100.203\wd_media\BINANCE_DATA"

# 交易费率
fee_rate = 0.00005
min_fee = 0.01


def get_realtime_data_path(date):
    """返回日期对应的实时数据路径 
    date: 20230901
    """
    path = os.path.join(realtime_root + '/ago/data',
                        date) if date < "20230906" else os.path.join(realtime_root, date) + "/data"

    # 检查路径是否存在
    if not os.path.exists(path):
        print(f"实时数据不存在: {path}")

    return path


def get_his_data_path(code, date):
    """
    返回日期对应的盘后历史数据路径 
    code: 513050
    date: 20230901
    """
    # 优先使用网络路径
    path = os.path.join(os.path.join(his_root, date), code)
    if not os.path.exists(path):
        print(f"server历史数据不存在: {path}")
        return ""

    return path


def get_his_times_binance():
    """返回所有的历史数据毫秒时间戳"""
    # 1708434355772 毫秒时间戳列表
    times_net = [i.replace("trade_", '') for i in os.listdir(
        his_binance_root) if "trade_" in i]

    times = list(set(times_net))
    times.sort()
    return times


def get_his_dates():
    """返回所有的历史数据日期"""
    # 8位 且全是数字
    dates_net = [i for i in os.listdir(
        his_root) if len(i) == 8 and i.isdigit()]

    dates = list(set(dates_net))
    dates.sort()
    return dates


def get_realtime_dates():
    """返回所有的实时录制数据日期"""
    # 8位 且全是数字
    return [i for i in os.listdir(realtime_root + '/ago/data') + os.listdir(realtime_root) if len(i) == 8 and i.isdigit()]


if __name__ == "__main__":
    his_dates = get_his_dates()
    realtime_dates = get_realtime_dates()
    print(his_dates)
    print(realtime_dates)
