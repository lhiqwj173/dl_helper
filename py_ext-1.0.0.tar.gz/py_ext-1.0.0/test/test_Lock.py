
from py_ext.tool import Lock, share_tensor
import threading, multiprocessing
import time, random

data = 0
def worker(num):
    """线程函数"""
    print(f'进程 {num}: 开始')
    global data
    lock = Lock("_test_lock")
    while True:
        if_modify = random.randint(0, 1)

        if if_modify:
            with lock:
                data += 1
                print(f"修改数据 > {data}")

        else:
            with lock:
                print(f"读取数据：{data}")

        time.sleep(random.random() * 2)

    print(f'进程 {num}: 结束')

def test_thread():
    threads = []

    # 创建三个线程
    for i in range(3):
        t = threading.Thread(target=worker, args=(i,))
        threads.append(t)
        t.start()

    # 等待所有线程结束
    for t in threads:
        t.join()

    print("所有线程都完成了！")

def process_worker(num):
    """进程函数"""
    print(f'进程 {num}: 开始')
    data = share_tensor("_test_data_sada", (1,), "int64")
    lock = Lock("_test_lock")
    while True:
        if_modify = random.randint(0, 1)

        if if_modify:
            with lock:
                data.data_np[0] += 1
                print(f"修改数据 > {data.data_np[0]}")
        else:
            with lock:
                print(f"读取数据：{data.data_np[0]}")

        time.sleep(random.random() * 2)

    print(f'进程 {num}: 结束')

def test_process():
    processes = []
    for i in range(3):
        p = multiprocessing.Process(target=process_worker, args=(i,))
        processes.append(p)
        p.start()

    for p in processes:
        p.join()

    print("所有进程都完成了！")

if __name__ == "__main__":
    # test_thread()
    test_process()
