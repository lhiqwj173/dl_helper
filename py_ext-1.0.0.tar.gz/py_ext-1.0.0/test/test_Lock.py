
from py_ext.tool import Lock
import threading
import time, random

data = 0
def worker(num):
    """线程函数"""
    print(f'进程 {num}: 开始')
    global data
    lock = Lock("_test_lock")
    while True:
        if_modify = random.randint(0, 1)

        if if_modify:
            with lock:
                data += 1
                print(f"修改数据 > {data}")

        else:
            with lock:
                print(f"读取数据：{data}")

        time.sleep(random.random() * 2)

    print(f'进程 {num}: 结束')

if __name__ == '__main__':
    threads = []

    # 创建三个线程
    for i in range(3):
        t = threading.Thread(target=worker, args=(i,))
        threads.append(t)
        t.start()

    # 等待所有线程结束
    for t in threads:
        t.join()

    print("所有线程都完成了！")
