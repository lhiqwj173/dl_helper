from py_ext.tool import share_tensor_list

import torch
import numpy as np
import unittest

def test_share_tensor_list():
    # 创建共享内存队列
    stl = share_tensor_list('test_share_tensor_list', (5, 2), 'float32', 10)
    stl_temp = stl.get_blank_same_data_local()

    print('写入数据')
    d = torch.randn(5, 2)
    stl.append(d)
    stl.append(d+2)
    print(stl._data)
    print('')

    print(f'stl数据数量: {stl.size()}, 获取数据，拷贝到 stl_temp')
    stl.all_copy_slice(stl_temp, 0)
    print(stl_temp)
    print('')

    print('写入数据')
    d = torch.randn(5, 2)
    stl.append(d)
    print(stl._data)
    print('')

    print(f'stl数据数量: {stl.size()}, 获取数据，拷贝到 stl_temp')
    stl.all_copy_slice(stl_temp, 4)
    print(stl_temp)
    print('')


class TestShareTensorList(unittest.TestCase):
    def setUp(self):
        # 创建一个基本的share_tensor_list实例用于测试
        self.shape = (2, 3)  # 测试2D张量
        self.dtype = 'float32'
        self.nums = 5
        self.stl = share_tensor_list('test', self.shape, self.dtype, self.nums)

    def test_initialization(self):
        """测试初始化是否正确"""
        self.assertEqual(self.stl.nums, self.nums)
        self.assertEqual(self.stl.shape(), self.shape)
        self.assertEqual(self.stl.size(), 0)  # 初始应该为空
        
        # 测试数据类型
        self.assertEqual(self.stl._data[0].dtype, torch.float32)
        self.assertEqual(len(self.stl._data), self.nums)

    def test_append_and_get(self):
        """测试append操作和获取数据"""
        # 创建测试数据
        test_tensor = torch.ones(self.shape)
        
        # 测试append
        self.stl.append(test_tensor)
        self.assertEqual(self.stl.size(), 1)
        
        # 验证数据是否正确存储
        np.testing.assert_array_equal(
            self.stl.get(0).numpy(),
            test_tensor.numpy()
        )

    def test_set_operation(self):
        """测试set操作"""
        test_tensor = torch.ones(self.shape) * 2
        self.stl.set(1, test_tensor)  # 设置索引1的数据
        
        # 验证数据
        self.assertEqual(self.stl.has_data.data[1].item(), 1)
        np.testing.assert_array_equal(
            self.stl.get(1).numpy(),
            test_tensor.numpy()
        )

    def test_continuous_and_non_continuous_data(self):
        """测试连续和非连续数据的存储和获取"""
        # 创建一些测试数据
        data1 = torch.ones(self.shape)
        data2 = torch.ones(self.shape) * 2
        data3 = torch.ones(self.shape) * 3
        
        # 设置非连续数据
        self.stl.set(0, data1)
        self.stl.set(2, data2)
        self.stl.set(4, data3)
        
        # 获取范围
        ranges, non_cont = self.stl._get_ranges()
        self.assertEqual(len(ranges), 0)  # 应该没有连续范围
        self.assertEqual(len(non_cont), 3)  # 应该有3个非连续点
        
        # 测试连续数据
        self.stl.reset()
        self.stl.set(0, data1)
        self.stl.set(1, data2)
        self.stl.set(2, data3)
        
        ranges, non_cont = self.stl._get_ranges()
        self.assertEqual(len(ranges), 1)  # 应该有1个连续范围
        self.assertEqual(ranges[0], (0, 2))  # 范围应该是0-2
        self.assertEqual(len(non_cont), 0)  # 应该没有非连续点

    def test_all_copy_slice(self):
        """测试数据拷贝功能"""
        # 创建测试数据
        data1 = torch.ones(self.shape)
        data2 = torch.ones(self.shape) * 2
        data3 = torch.ones(self.shape) * 3
        
        # 设置一些数据
        self.stl.set(0, data1)
        self.stl.set(1, data2)
        self.stl.set(3, data3)  # 注意这里是索引3，创建不连续情况
        
        # 创建目标tensor
        dst_data = self.stl.get_blank_same_data_local()
        
        # 执行拷贝
        self.stl.all_copy_slice(dst_data)
        
        # 验证数据
        np.testing.assert_array_equal(dst_data[0].numpy(), data1.numpy())
        np.testing.assert_array_equal(dst_data[1].numpy(), data2.numpy())
        np.testing.assert_array_equal(dst_data[2].numpy(), data3.numpy())

    def test_full_buffer(self):
        """测试缓冲区满的情况"""
        # 填满缓冲区
        test_tensor = torch.ones(self.shape)
        for i in range(self.nums):
            self.stl.append(test_tensor)
        
        # 尝试再添加一个，应该失败
        self.stl.append(test_tensor)  # 应该打印满的消息
        self.assertEqual(self.stl.size(), self.nums)

    def test_reset(self):
        """测试reset功能"""
        # 添加一些数据
        test_tensor = torch.ones(self.shape)
        self.stl.append(test_tensor)
        self.stl.append(test_tensor)
        
        # 验证数据存在
        self.assertEqual(self.stl.size(), 2)
        
        # 重置
        self.stl.reset()
        
        # 验证数据被清除
        self.assertEqual(self.stl.size(), 0)
        self.assertTrue((self.stl.has_data.data == 0).all())

    def tearDown(self):
        """清理测试环境"""
        self.stl.reset()
        # 可能需要添加其他清理代码，比如释放共享内存

if __name__ == '__main__':
    test_share_tensor_list()
    unittest.main()
