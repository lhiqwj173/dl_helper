import multiprocessing
import os,random
import time

from py_ext.tool import Event

# 定义一个函数用于子进程1的任务
def task1():
    print(f"setter PID: {os.getpid()}")
    event = Event('test_event')
    for _ in range(5):
        print("set event")
        event.set()
        time.sleep(random.randint(1, 3))

# 定义一个函数用于子进程2的任务
def task2():
    _pid = os.getpid()
    print(f"waiter PID: {_pid}")
    event = Event('test_event')
    for _ in range(5):
        if event.is_set():
            print(f"[{_pid}] event is set")
            event.clear()
        else:
            print(f"[{_pid}] event is not set")
        time.sleep(random.randint(1, 3))

if __name__ == "__main__":
    # 创建子进程1
    p1 = multiprocessing.Process(target=task1)
    # 创建子进程2
    p2 = multiprocessing.Process(target=task2)
    p3 = multiprocessing.Process(target=task2)

    # 启动子进程1
    p1.start()
    # 启动子进程2
    p2.start()
    p3.start()


    # 等待子进程1结束
    p1.join()
    # 等待子进程2结束
    p2.join()
    p3.join()

    print("All processes are done.")