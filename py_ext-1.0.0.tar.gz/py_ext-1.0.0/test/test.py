import os
import time
import datetime
import zipfile
import shutil

from py_ext.tool import unzip
from py_ext.trade_helper import if_trade_date, pre_trade_date, next_trade_date

if __name__ == "__main__":
    pd = pre_trade_date(n=2)
    print(pd)

    nd = next_trade_date()
    print(nd)
