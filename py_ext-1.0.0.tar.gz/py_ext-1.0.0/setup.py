from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess
import platform, os

class CustomInstallCommand(install):
    def run(self):
        # 在安装时执行自定义操作
        print(f"check requirements install...")
        if platform.system() != 'Windows':
            file7z = '/usr/bin/7z'
            if not os.path.exists(file7z):
                # 安装 7z
                cmd = 'apt-get install p7zip-full -y'
                subprocess.call(cmd, shell=True)
                print(f"install 7z")

            # 安装 posix_ipc
            cmd = 'pip install posix_ipc'
            subprocess.call(cmd, shell=True)
            print(f"install posix_ipc")

        # 继续执行默认的安装操作
        install.run(self)

setup(
    name='py_ext',
    version='1.0.0',
    packages=find_packages(),
    install_requires=open('requirements.txt').readlines(),
    setup_requires=[
        'setuptools_scm'
    ],
    cmdclass={
        'install': CustomInstallCommand,
    },
)
