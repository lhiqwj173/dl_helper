import socket
import time
import datetime
import subprocess
import sys
import statistics
import ctypes
import traceback
from ctypes import windll
import platform
if platform.system() == "Windows":
    import win32api
    # 提升进程优先级以获得更好的时间精度
    windll.kernel32.SetThreadPriority(windll.kernel32.GetCurrentThread(), 31)  # THREAD_PRIORITY_TIME_CRITICAL
import argparse

from py_ext.tool import init_logger, log
from py_ext.wechat import send_wx

init_logger('time_sync')

def get_time_str(t1, t2=None):
    # t1 = time.time()
    if t2 is None:
        formatted_time = "{:.7f}".format(t1)  # 保留 7 位小数
    else:
        formatted_time = "{:.7f},{:.7f}".format(t1, t2)  # 保留 7 位小数

    # print(f'原始值: \t{t1}')
    # print(f'完整精度: \t{t1:.20f}')  # 显示更多小数位
    # print(f'格式化后: \t{formatted_time}')
    return formatted_time

# 定义SYSTEMTIME结构体
class SYSTEMTIME(ctypes.Structure):
    _fields_ = [
        ("wYear", ctypes.c_uint16),
        ("wMonth", ctypes.c_uint16),
        ("wDayOfWeek", ctypes.c_uint16),
        ("wDay", ctypes.c_uint16),
        ("wHour", ctypes.c_uint16),
        ("wMinute", ctypes.c_uint16),
        ("wSecond", ctypes.c_uint16),
        ("wMilliseconds", ctypes.c_uint16)
    ]
    
def set_system_time(timestamp):
    """高精度设置系统时间"""
    try:
        # 将时间戳转换为UTC时间
        utc_time = datetime.datetime.utcfromtimestamp(timestamp)
        
        # 创建并设置SYSTEMTIME结构体实例
        system_time = SYSTEMTIME()
        system_time.wYear = utc_time.year
        system_time.wMonth = utc_time.month
        system_time.wDay = utc_time.day
        system_time.wHour = utc_time.hour
        system_time.wMinute = utc_time.minute
        system_time.wSecond = utc_time.second
        system_time.wMilliseconds = int(utc_time.microsecond / 1000)

        # 使用Win32 API直接设置时间
        win32api.SetSystemTime(
            system_time.wYear,
            system_time.wMonth,
            1,  # dayOfWeek (ignored)
            system_time.wDay,
            system_time.wHour,
            system_time.wMinute,
            system_time.wSecond,
            system_time.wMilliseconds
        )
    except Exception as e:
        log(f"设置时间出错: \n{traceback.format_exc()}")

def recv_all(sock, length):
    data = b''
    remaining = length
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise ConnectionError("连接断开")
        data += chunk
        remaining -= len(chunk)
    return data

class TimeSync:
    def __init__(self, mode, host='0.0.0.0', port=3491):
        self.mode = mode
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # 设置TCP_NODELAY以减少延迟
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        # # 设置发送和接收缓冲区大小为最小值以减少延迟
        # self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1)
        # self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1)
        
        # 用于存储同步统计数据
        self.delays = []
        self.offsets = []
        self.sync_window = 10  # 同步窗口大小
        self.max_samples = 30  # 最大样本数
        self.precision_threshold = 0.0001  # 0.1ms阈值
        
    def run_server(self):
        self.sock.bind((self.host, self.port))
        self.sock.listen(1)
        log(f"服务器模式启动于 {self.host}:{self.port}")
        
        conn, addr = self.sock.accept()
        log(f"客户端 {addr} 已连接")

        recv_length = get_time_str(time.time()).encode().__len__()
        
        try:
            while True:
                # T1: 客户端发送时间
                # log(f'wait t1')
                data = recv_all(conn, recv_length)
                # log(f'recv data: {data}')
                t1 = float(data.decode())
                # log(f'recv t1: {t1}')
                # T2: 服务器接收时间
                t2 = time.time()
                # T3: 服务器发送时间
                t3 = time.time()
                response = get_time_str(t2, t3)
                # log(f'send response: {response}')
                conn.sendall(response.encode())
                log(f'send response: {response}')
        except Exception as e:
            log(f"服务器错误: \n{traceback.format_exc()}")
        finally:
            conn.close()
            self.sock.close()
        
    def run_client(self):
        try:
            self.sock.connect((self.host, self.port))
            log(f"已连接到服务器 {self.host}:{self.port}")
            
            recv_length = get_time_str(time.time(), time.time()+1).encode().__len__()

            # 代码层面的偏移
            act_time_diffs = []

            correct_count = 0
            while True:
                try:
                    # T1: 客户端发送时间
                    t1 = time.time()
                    # log(f'send t1: {t1}')
                    self.sock.sendall(get_time_str(t1).encode())   # 使用13.6f格式
                    # log(f'send t1: {t1} done')
                    
                    data = recv_all(self.sock, recv_length).decode()
                    # log(f'recv data: {data}')
                    # T4: 客户端接收时间
                    t4 = time.time()
                    data = data.split(',')
                    t2 = float(data[0])
                    t3 = float(data[1])
                    # log(f'recv t2: {t2}, recv t3: {t3}')

                    # 计算网络延迟和时间偏移
                    delay = ((t4 - t1) - (t3 - t2)) / 2
                    offset = ((t2 - t1) + (t3 - t4)) / 2

                    log(f"延迟: {int(delay*1000)}ms, 偏移: {offset*1000:.3f}ms")
                    
                    # 过滤异常值
                    if delay > 0 and delay < 1:  # 只接受1000ms以内的延迟
                        self.delays.append(delay)
                        self.offsets.append(offset)
                        
                        # 保持固定样本数
                        if len(self.delays) > self.max_samples:
                            self.delays.pop(0)
                            self.offsets.pop(0)
                        
                        # 当收集足够样本且延迟稳定时进行同步
                        if len(self.delays) >= self.sync_window:
                            recent_delays = self.delays[-self.sync_window:]
                            recent_offsets = self.offsets[-self.sync_window:]
                            
                            # 计算延迟和偏移的统计值
                            delay_std = statistics.stdev(recent_delays)
                            delay_mean = statistics.mean(recent_delays)
                            offset_median = statistics.median(recent_offsets)

                            # 第一次调整后的偏移 认为是系统误差
                            if correct_count > 0:
                                act_time_diffs.append(offset_median)
                            act_time_diff = statistics.mean(act_time_diffs) if len(act_time_diffs) > 0 else 0

                            log(f"延迟标准差: {delay_std*1000:.3f}ms")
                            log(f"延迟均值: {delay_mean*1000:.3f}ms")
                            log(f"偏移中位数: {offset_median*1000:.3f}ms")
                            log(f"系统误差: {act_time_diff*1000:.3f}ms")
                            
                            # 只在延迟稳定且偏移显著时同步
                            if (delay_std < self.precision_threshold and 
                                abs(offset_median) > self.precision_threshold):

                                # 计算补偿后的时间
                                current_time = time.time()
                                adjusted_time = current_time + offset_median + act_time_diff
                                
                                # 设置系统时间
                                set_system_time(adjusted_time)
                                log(f"同步完成 - 偏移: {offset_median*1000:.3f}ms, 延迟: {delay_mean*1000:.3f}ms")
                                correct_count += 1

                                if correct_count > 5:
                                    break
                                
                                # 清空历史数据重新开始采样
                                self.delays.clear()
                                self.offsets.clear()
                    
                    time.sleep(1)
                    
                except Exception as e:
                    log(f"同步错误: \n{traceback.format_exc()}")
                    raise e
                    
        except Exception as e:
            log(f"客户端错误: \n{traceback.format_exc()}")
            raise e
        finally:
            self.sock.close()

        send_wx(f"校对时间完成")

def sync_time():
    parser = argparse.ArgumentParser(description='高精度时间同步工具')
    parser.add_argument('mode', choices=['server', 'client'], help='运行模式: server或client')
    parser.add_argument('--host', default='0.0.0.0', help='服务器模式下绑定的IP，默认0.0.0.0')
    parser.add_argument('--port', type=int, default=3491, help='使用的端口号，默认3491')
    parser.add_argument('--server-ip', default='127.0.0.1', help='客户端模式下要连接的服务器IP')
    
    args = parser.parse_args()
    
    if args.mode == 'client' and not args.server_ip:
        parser.error('客户端模式需要提供服务器IP (--server-ip)')
    
    # 检查管理员权限
    if not ctypes.windll.shell32.IsUserAnAdmin():
        log("警告: 需要管理员权限来设置系统时间")
        sys.exit(1)
    
    host = args.server_ip if args.mode == 'client' else args.host
    sync = TimeSync(args.mode, host, args.port)
    
    if args.mode == 'server':
        sync.run_server()
    else:
        sync.run_client()

if __name__ == "__main__":
    # for i in range(10):
    #     t = time.time()
    #     print(get_time_str(t))
    #     print(datetime.datetime.fromtimestamp(t))
    #     time.sleep(1)

    # print(get_time_str(time.time(), time.time()+1))

    # t1 = 1739621251.5998387
    # t2 = 1739592451.625965
    # t3 = 1739592451.625965
    # t4 = 1739621251.6310632
    # delay = ((t4 - t1) - (t3 - t2)) / 2
    # offset = ((t2 - t1) + (t3 - t4)) / 2
    # print(f'delay: {delay}, offset: {offset}, t2-t1: {t2-t1}, t3-t4: {t3-t4}')

    # t = time.time()
    # dt = datetime.datetime.utcfromtimestamp(t)
    # print(dt)
    sync_time()