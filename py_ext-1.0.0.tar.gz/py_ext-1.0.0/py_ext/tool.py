import sys
import socket
import time
import datetime
import shutil
import os, math, torch
import ctypes
import traceback
import gzip
import lzma
import tarfile
import zipfile
from joblib import Parallel, delayed
import atexit
from multiprocessing import shared_memory
import numpy as np
import requests
from bs4 import BeautifulSoup

from loguru import logger
from py_ext.wechat import wx

import platform

if platform.system() == 'Linux':
    import posix_ipc
    import fcntl
    import struct
else:
    from ctypes import windll, wintypes

class safe_share_memory:
    def __init__(self, name, size):
        self.name = name
        self.size = size
        
        try:
            self.shm = shared_memory.SharedMemory(name=name, create=True, size=size)
            print(f"{id(self)} create shared memory {name} success")
        except FileExistsError:
            self.shm = shared_memory.SharedMemory(name=name)
            print(f"{id(self)} use shared memory {name}")
        except Exception as e:
            print(f"{id(self)} create shared memory {name} failed, {e}")

    def __del__(self):
        try:
            print(f"{id(self)} delete shared memory {self.name}")
            self.shm.unlink()
            self.shm.close()
        except Exception as e:
            print(f"{id(self)} delete shared memory {self.name} failed, ignore")

    def get(self):
        return self.shm
    
class safe_share_memory_queue:
    def __init__(self, name, size, nums=10):
        self.name = name
        self.size = size
        self._maxsize = nums

        # 分配数据内存
        self._ssm = safe_share_memory(name=name, size=size * nums)
        self._data = []
        for i in range(nums):
            buffer = memoryview(self._ssm.get().buf)[i * size:(i + 1) * size]
            self._data.append(buffer)

        # 记录各个索引对应数据插入的顺序，若没有使用，则置为-1
        # 记录各个索引对应数据的长度
        # 记录已经使用的索引数量
        self._info_shm = safe_share_memory(name=name + "_info", size=nums * 4 * 2 + 4)
        buffer = memoryview(self._info_shm.get().buf)
        self._order_np = np.frombuffer(buffer[:nums*4], dtype=np.int32)
        self._length_np = np.frombuffer(buffer[nums*4:nums*8], dtype=np.int32)
        self._used_num_np = np.frombuffer(buffer[nums*8:], dtype=np.int32)

        self._lock = Lock(name + "_safe_share_memory_queue_lock")

    def __del__(self):
        del self._length_np
        del self._order_np
        del self._used_num_np
        del self._info_shm
        del self._data
        del self._ssm

    def clear(self):
        with self._lock:

            self._order_np[:] = -1
            self._length_np[:] = 0
            self._used_num_np[0] = 0

    def put(self, data:bytes):
        log_wait = False
        print(f'put data length: {len(data)}')
        while True:
            with self._lock:
                # 0. 检查
                if len(data) > self.size:
                    raise ValueError(f"Data size {len(data)} exceeds buffer size {self.size}")
                if self._used_num_np[0] != self._maxsize:
                    # 1. 查找空闲的索引
                    free_idx = -1
                    for i in range(self._maxsize):
                        if self._order_np[i] == -1:
                            free_idx = i
                            break
                    
                    if free_idx == -1:
                        raise RuntimeError("No free slot found but queue is not full, code error!!!")

                    # 2. 将数据写入到共享内存中
                    data_length = len(data)
                    buffer = self._data[free_idx]
                    buffer[:data_length] = data

                    # 3. 更新索引信息
                    self._length_np[free_idx] = data_length
                    # 获取当前最大order，新数据的order要比它大1
                    current_max_order = -1
                    for order in self._order_np:
                        if order > current_max_order:
                            current_max_order = order
                    self._order_np[free_idx] = current_max_order + 1
                    self._used_num_np[0] += 1
                    return
                
            if not log_wait:
                print(f'put failed, queue is full, wait and retry...')
                log_wait = True
            time.sleep(0.01)


    def get(self):
        log_wait = False
        print(f'get data')
        while True:
            with self._lock:
                if self._used_num_np[0] != 0:
                    # 1. 查找最小的索引(除-1外)
                    min_order = float('inf')
                    min_idx = -1
                    for i in range(self._maxsize):
                        if self._order_np[i] != -1 and self._order_np[i] < min_order:
                            min_order = self._order_np[i]
                            min_idx = i

                    if min_idx == -1:
                        raise RuntimeError("No valid data found but queue is not empty, code error!!!")

                    # 2. 获取数据
                    data_length = self._length_np[min_idx]
                    data = bytes(self._data[min_idx][:data_length])

                    # 3. 更新索引信息
                    self._order_np[min_idx] = -1
                    # self._length_np[min_idx] = 0 # 不需要更新
                    self._used_num_np[0] -= 1

                    return data
                
            if not log_wait:
                print(f'get failed, queue is empty, wait and retry...')
                log_wait = True
            time.sleep(0.01)
                    
    def is_empty(self):
        with self._lock:
            return self._used_num_np[0] == 0

    def is_full(self):  
        with self._lock:
            return self._used_num_np[0] == self._maxsize

    def __len__(self):  
        with self._lock:
            return self._used_num_np[0]

    def qsize(self):
        with self._lock:
            return self._used_num_np[0]

def get_total_elements(shape):
    """计算给定 shape 的元素总数，支持 list, tuple, torch.Size, numpy.shape"""

    if isinstance(shape, torch.Size):
        return torch.prod(torch.tensor(shape)).item() # 将 torch.Size 转换为 tensor 后计算乘积
    elif isinstance(shape, (list, tuple)):
        return math.prod(shape) if shape else 0 # 兼容空shape
    else:
        raise TypeError("Unsupported shape type")

def get_ndarray_size(shape, dtype:str):
    nums = get_total_elements(shape)
    np_dtype = np.dtype(dtype)
    # 计算基础大小
    size = np_dtype.itemsize * nums
    return size

class share_tensor:
    def __init__(self, name, shape, dtype:str):
        # 计算需要的内存大小
        size = get_ndarray_size(shape, dtype)

        # 申请共享内存
        self.ssm = safe_share_memory(name, size)
        self.shm = self.ssm.get()
        
        # 创建ndarray / torch.Tensor
        self.data_np = np.ndarray(shape, dtype=dtype, buffer=self.shm.buf)
        self.data = torch.from_numpy(self.data_np)

    def shape(self):
        return self.data_np.shape

class share_tensor_list:
    def __init__(self, name, shape, dtype:str, nums:int, debug=False):
        # 计算需要的内存大小
        self.one_size = get_ndarray_size(shape, dtype)
        self._size = self.one_size * nums
        self.nums = nums
        self.debug = debug
        self.name = name

        # 申请共享内存 数据
        self.ssm = safe_share_memory(f'snl_{name}_data', self._size)
        self.shm = self.ssm.get()
        self._data_np = []
        self._data = []
        for i in range(nums):
            # 使用frombuffer替代直接创建，更安全
            buffer = memoryview(self.shm.buf)[i * self.one_size:(i + 1) * self.one_size]
            arr = np.ndarray(shape=shape, dtype=dtype, buffer=buffer)
            self._data_np.append(arr)
            self._data.append(torch.from_numpy(arr))

        # 申请共享内存 索引 begin/end
        self.ssm_index = safe_share_memory(f'snl_{name}_index', 2 * 8)
        self.shm_index = self.ssm_index.get()
        self.index = np.ndarray(shape=(2,), dtype=np.int64, buffer=self.shm_index.buf)

    def get(self, idx):
        return self._data[idx]

    def all_copy_slice(self, dst_data:torch.Tensor, begin=0):
        # 获取所有数据, 拷贝到 dst_data 的begin开始的位置
        # 完成后reset 清空
        raw_data = self.shm.buf[self.index[0]*self.one_size:self.index[1]*self.one_size]
        dst_data.numpy()[begin:begin +self.index[1]] = np.frombuffer(raw_data, dtype=self._data_np[0].dtype).reshape(-1, *self._data_np[0].shape)
        self.reset()

    def get_blank_same_data_local(self):
        # 使用 tensor 创建一个空的数据，维度与共享数据一致，(nums, *shape) 
        return torch.ones(tuple([self.nums] + list(self._data_np[0].shape)))

    def size(self):
        return self.index[1]

    def shape(self):
        return self._data_np[0].shape

    def reset(self):
        self.index[0] = 0
        self.index[1] = 0

    def append(self, tensor):
        if self.index[1] >= self.nums:
            print(f'{id(self)} shared memory {self.name} is full')
            return
        if self.debug:
            print(f'{id(self)} shared memory {self.name} append, self.index: {self.index}, len(self._data): {len(self._data)}')
        # 直接使用numpy数组的复制操作
        self._data[self.index[1]][:] = tensor
        self.index[1] += 1

    def set(self, idx, tensor):
        self._data[idx][:] = tensor
        self.index[1] = max(self.index[1], idx + 1)

class Semaphore:
    def __init__(self, name=None, max_count=1):
        """
        弃用 使用Event替代
        初始化跨平台信号量
        :param name: 信号量名称，为None时自动生成唯一名称
        :param max_count: 最大并发数，默认为1
        """
        raise Exception(f'弃用 使用Event替代')
        self.max_count = max_count
        self._is_set = False
        
        if name is None:
            # 生成唯一名称
            name = f"/sem_{os.getpid()}_{id(self)}"
        
        if os.name == 'posix':
            # Linux实现
            import posix_ipc
            self._impl = 'posix'
            self.sem = posix_ipc.Semaphore(
                name, 
                flags=posix_ipc.O_CREAT, 
                initial_value=0  # 初始状态为未设置
            )
        else:
            # Windows实现
            kernel32 = ctypes.windll.kernel32
            self._impl = 'windows'
            self.sem = kernel32.CreateSemaphoreW(
                None,    # 默认安全属性
                0,       # 初始计数为0
                max_count,  # 最大计数
                name     # 信号量名称
            )
            if self.sem == 0:
                raise WindowsError("Failed to create semaphore")
        
        # 注册清理函数
        atexit.register(self._cleanup)

    def acquire(self, blocking=True, timeout=None):
        """
        获取信号量
        :param blocking: 是否阻塞
        :param timeout: 超时时间（秒），None表示无限等待
        """
        if self._impl == 'posix':
            import posix_ipc
            try:
                if not blocking:
                    # 非阻塞模式
                    self.sem.acquire(0)
                elif timeout is not None:
                    # 带超时的阻塞
                    self.sem.acquire(timeout)
                else:
                    # 无限阻塞
                    self.sem.acquire()
            except posix_ipc.BusyError:
                return False
            return True
        
        else:
            # Windows实现
            kernel32 = ctypes.windll.kernel32
            
            # 转换超时时间为毫秒
            if timeout is not None:
                wait_time = int(timeout * 1000)
            else:
                wait_time = -1 if blocking else 0
            
            result = kernel32.WaitForSingleObject(self.sem, wait_time)
            
            # 0 表示成功获取，WAIT_TIMEOUT 表示超时
            return result == 0

    def release(self, count=1):
        """
        释放信号量
        :param count: 释放的信号量数量
        """
        if self._impl == 'posix':
            for _ in range(count):
                self.sem.release()
        else:
            kernel32 = ctypes.windll.kernel32
            previous_count = ctypes.c_long()
            kernel32.ReleaseSemaphore(
                self.sem, 
                count, 
                ctypes.byref(previous_count)
            )

    def wait(self, timeout=None):
        """
        等待信号量被设置
        :param timeout: 超时时间（秒），None表示无限等待
        :return: 是否成功等到信号
        """
        return self.acquire(blocking=True, timeout=timeout)

    def set(self):
        """
        设置信号量，释放所有等待的线程/进程
        """
        if not self._is_set:
            self._is_set = True
            # 释放最大并发数量的信号量
            self.release(self.max_count)

    def clear(self):
        """
        清除信号量，重置为未设置状态
        """
        if self._is_set:
            self._is_set = False
            # 尝试获取并消耗所有已存在的信号量
            while self.acquire(blocking=False):
                pass

    def is_set(self):
        """
        检查信号量是否已设置
        :return: 是否已设置
        """
        return self._is_set

    def __enter__(self):
        """上下文管理器支持"""
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器支持"""
        self.release()

    def _cleanup(self):
        """清理资源"""
        if self._impl == 'posix':
            # Linux下直接取消链接和关闭
            self.sem.unlink()
            self.sem.close()
        else:
            # Windows关闭句柄
            kernel32 = ctypes.windll.kernel32
            kernel32.CloseHandle(self.sem)

import platform

if platform.system() == 'Linux':
    import posix_ipc
    import fcntl
    import struct
else:
    from ctypes import windll, wintypes

class Lock:
    def __init__(self, name):
        self.name = name
        self.system = platform.system()

        if self.system == 'Windows':
            # 创建或打开一个命名互斥体
            self.mutex = ctypes.windll.kernel32.CreateMutexW(
                None,                   # 默认安全属性
                False,                  # 初始所有权
                f"Global\\{name}"       # 互斥体名称
            )
            if not self.mutex:
                raise ctypes.WinError()
        else:
            self.mutex = posix_ipc.Semaphore(f"/{name}_mutex", flags=posix_ipc.O_CREAT, initial_value=1)

    def __enter__(self):
        if self.system == 'Windows':
            # 等待互斥体，INFINITE 表示无限等待
            result = ctypes.windll.kernel32.WaitForSingleObject(
                self.mutex,
                wintypes.DWORD(-1)  # INFINITE
            )
            if result != 0:  # WAIT_OBJECT_0
                raise ctypes.WinError()
        else:
            self.mutex.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.system == 'Windows':
            # 释放互斥体
            if not ctypes.windll.kernel32.ReleaseMutex(self.mutex):
                raise ctypes.WinError()
        else:
            self.mutex.release()

    def __del__(self):
        """确保互斥体被正确关闭"""
        if self.system == 'Windows':
            ctypes.windll.kernel32.CloseHandle(self.mutex)
        else:
            self.mutex.unlink()


class Event:
    def __init__(self, name):
        self.name = name
        self.system = platform.system()

        if self.system == 'Windows':
            # Windows-specific initialization using Win32 API
            self.handle = windll.kernel32.CreateEventA(
                None,   # default security attributes
                True,   # manual reset
                False,  # initial state is not signaled
                name.encode()  # event name
            )
            if not self.handle:
                raise RuntimeError(f"Failed to create event {name}")
        elif self.system in ('Linux', 'Darwin'):  # Darwin for macOS, although not explicitly handled
            # Initialize for POSIX systems (Linux, macOS)
            try:
                self.sem = posix_ipc.Semaphore(f"/{name}")
            except posix_ipc.ExistentialError:
                self.sem = posix_ipc.Semaphore(f"/{name}", flags=posix_ipc.O_CREAT, initial_value=0)

            self.mutex = posix_ipc.Semaphore(f"/{name}_mutex", flags=posix_ipc.O_CREAT, initial_value=1)
            # print(f'mutex v: {self.mutex.value}')
        
        else:
            raise RuntimeError(f"Unsupported operating system: {self.system}")

    def set(self, n=-1):
        """
        n : linux 下的信号量增加次数
        """
        if self.system == 'Windows':
            windll.kernel32.SetEvent(self.handle)
        else:
            # Release the semaphore for all waiting processes
            n = n if n > 0 else 10

            self.mutex.acquire()
            for _ in range(n):  # Assuming no more than 10 processes will wait; adjust if needed
                self.sem.release()
            self.mutex.release()

    def clear(self):
        if self.system == 'Windows':
            windll.kernel32.ResetEvent(self.handle)
        else:
            # Reset the event by decrementing the semaphore count back to zero
            self.mutex.acquire()
            while self.sem.value > 0:
                self.sem.acquire()
            self.mutex.release()

    def clear_reset(self, n=-1):
        """
        针对 linux
            将信号量控制在n个
        """
        if self.system == 'Windows':
            windll.kernel32.SetEvent(self.handle)
        else:
            n = n if n > 0 else 10

            self.mutex.acquire()
            cur_n = self.sem.value
            if cur_n == n:
                pass
            elif cur_n > n:
                for _ in range(cur_n - n):
                    self.sem.acquire()
            elif cur_n < n:
                for _ in range(n - cur_n):
                    self.sem.release()

            self.mutex.release()

    def wait(self, timeout=None):
        if self.system == 'Windows':
            timeout_ms = int(timeout * 1000) if timeout is not None else 0xFFFFFFFF
            result = windll.kernel32.WaitForSingleObject(self.handle, timeout_ms)
            return result == 0  # Return whether the wait was successful
        else:
            try:
                self.sem.acquire(timeout)
                return True
            except posix_ipc.BusyError:
                return False

    def is_set(self):
        """
        立即检查事件是否被设置
        :return: bool 事件是否被设置
        """
        if self.system == 'Windows':
            # 使用0超时来立即检查状态
            result = windll.kernel32.WaitForSingleObject(self.handle, 0)
            return result == 0
        else:
            # 对于POSIX系统，检查信号量的值
            return self.sem.value > 0

    def close(self):
        if self.system == 'Windows':
            if hasattr(self, 'handle'):
                windll.kernel32.CloseHandle(self.handle)
        else:
            for i in [self.sem, self.mutex]:
                try:
                    self.sem.unlink()
                except:
                    pass  # If the semaphore doesn't exist, just ignore the error
    
    def __del__(self):
        self.close()
                     
def get(url, headers={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
}, **kwargs):
    # 发起HTTP请求，获取网页内容
    response = requests.get(url, headers=headers, **kwargs)
    content = response.text

    # 解析网页内容
    soup = BeautifulSoup(content, "html.parser")

    return soup


def download(url, file_path, headers={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
}, **kwargs):
    response = requests.get(url, headers=headers, **kwargs)
    # 确保请求成功
    if response.status_code == 200:
        with open(file_path, "wb") as file:
            file.write(response.content)
    else:
        raise Exception(f"文件下载失败: {response}")


def full_cpu_run_different_func(*objs):
    """
    每个 obj 为一个列表, 第一个元素为函数, 后面的元素为函数的参数
    """
    # 并行执行任务
    return Parallel(n_jobs=-1)(delayed(obj[0])(*obj[1:]) for obj in objs)


def full_cpu_run_same_func(func, args):
    """
    按照cpu核心数并行执行任务
    args 为参数列表，每个元素为单次任务的参数(可以是列表)
    """
    # 并行执行任务
    if (isinstance(args[0], list) or isinstance(args[0], tuple)) and len(args[0]) > 1:
        # 多个参数
        return Parallel(n_jobs=-1)(delayed(func)(*_args) for _args in args)

    else:
        # 单个参数
        return Parallel(n_jobs=-1)(delayed(func)(_args) for _args in args)


def send_file(file_name):
    # 发送微信
    wechat.wx.send_file(file_name)


def if_trade():
    model_path = wechat.__file__
    trade_date_file = model_path.replace('wechat.py', 'TRADE_DATE')

    today = time.strftime("%Y-%m-%d", time.localtime())
    with open(trade_date_file, 'r')as f:
        trade_dates = f.read().split('\n')
        if today in trade_dates:
            return 1
        else:
            return 0


def next_trade(dt):
    model_path = wechat.__file__
    trade_date_file = model_path.replace('wechat.py', 'TRADE_DATE')

    today = time.strftime("%Y-%m-%d", time.localtime())
    # 2021-01-01 09:30:30
    date = dt[:10]
    with open(trade_date_file, 'r')as f:
        trade_dates = f.read().split('\n')
        trade_dates = [i for i in trade_dates if (i > date and i < today)]

        if trade_dates:
            return int(time.mktime(time.strptime(trade_dates[0], '%Y-%m-%d')))
        else:
            return 0


log_dir = ''


def get_log_folder():
    return log_dir

log_file = ''
def init_logger(name, enqueue=False, level='INFO', home='', timestamp=True):
    # enqueue : 是否将日志写入队列(多进程)
    # 获取~目录
    home = os.path.expanduser('~') if not home else home

    # 创建日志目录
    global log_dir
    log_dir = os.path.join(home, 'logs')

    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 创建日志文件
    global log_file
    name = name.replace('.', '_')
    file_name = f'{name}_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")}.log' if timestamp else f'{name}.log'
    log_file = os.path.join(log_dir, file_name)

    logger.remove()  # 先移除默认的日志处理器

    # 添加日志处理器
    logger.add(log_file, enqueue=enqueue, format="{time:YYYY-MM-DD hh:mm:ss} | {message}",
               retention=datetime.timedelta(weeks=1), level=level)

    # # 添加控制台处理器
    logger.add(sys.stdout, enqueue=enqueue,
               format="{time:YYYY-MM-DD hh:mm:ss} | {message}", level=level)

    # 清理久期文件 7天前的文件
    for file in os.listdir(log_dir):
        file = os.path.join(log_dir, file)
        if os.path.isfile(file):
            if os.path.getmtime(file) < time.time() - 7 * 24 * 60 * 60:
                logger.info(
                    f'清理日志文件: {file}, {datetime.datetime.fromtimestamp(os.path.getmtime(file)).strftime("%Y-%m-%d")}')

                try:
                    os.remove(file)
                except:
                    pass

def get_log_file():
    return log_file

def _get_caller_info():
    """
    获取调用者的信息
    """
    caller_info = sys._getframe(2)
    return caller_info.f_code.co_filename.split('\\')[-1], caller_info.f_code.co_name, str(caller_info.f_lineno)


def log(*msg, caller_info=None):
    msg = [str(i) for i in msg]
    msg = ':'.join(_get_caller_info(
    ) if None is caller_info else caller_info) + " - " + ' '.join(msg)
    logger.info(msg)


def debug(*msg, caller_info=None):
    msg = [str(i) for i in msg]
    msg = ':'.join(_get_caller_info(
    ) if None is caller_info else caller_info) + " - " + ' '.join(msg)
    logger.debug(msg)

##################################################################
# 异常捕捉
##################################################################

def get_exception_msg():
    return traceback.format_exc()

def unhandled_exception(exc_type, exc_value, exc_traceback):
    # 排除 KeyboardInterrupt
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return

    # 保持命令行原有的错误输出
    sys.__excepthook__(exc_type, exc_value, exc_traceback)
    
    # 同时发送到微信
    msg_list = traceback.format_exception(exc_type, exc_value, exc_traceback)
    msg = ''.join(msg_list)
    wx.send_message(f'异常捕捉\n{exc_type}\n{exc_value}\n{msg}')


# 设置异常处理钩子
sys.excepthook = unhandled_exception

##################################################################
# 异常捕捉
##################################################################


def unzip(filepath, output_dir):
    zip_file = zipfile.ZipFile(filepath)
    zip_list = zip_file.namelist()

    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    for f in zip_list:
        try:
            nf = f.encode('cp437').decode('gbk')
        except:
            nf = f.encode('utf-8').decode('utf-8')
        new_path = os.path.join(output_dir, nf)
        # 判断f是否是目录，目录的结尾是'/'或'\'
        if f[-1] not in ['\\', '/']:
            with open(new_path, 'wb') as file:
                file.write(zip_file.read(f))
                file.close()
        else:
            os.mkdir(new_path)
    zip_file.close()


def _uncompress_file(uncompress, ext_str, input_path, output_path, inplace):
    """解压文件"""
    ext_str = ext_str.replace(".", "")
    folder_ext = f'.tar.{ext_str}'

    if None is output_path:
        # 指定解压缩文件夹
        output_path = os.path.dirname(input_path)

        # 如果是文件夹 解压缩目录为文件名称
        if input_path.endswith(folder_ext):
            output_path = input_path[:-len(folder_ext)]
            os.makedirs(output_path, exist_ok=True)

    else:
        # 确保文件夹存在
        os.makedirs(output_path, exist_ok=True)

    # 如果是压缩文件为单文件 输出路径增加文件名称
    if not input_path.endswith(folder_ext):
        output_path = os.path.join(output_path, os.path.basename(
            input_path)[:-len(f'.{ext_str}')])

    uncompress(input_path, output_path)

    # 解压完成后删除源文件
    if inplace:
        os.remove(input_path)

    return output_path


def _compress_file(compress, ext_str, input_path, output_path, inplace):
    """压缩文件"""
    if None is output_path:
        # 替换后缀
        output_path = input_path + \
            f".{ext_str}" if ext_str[0] != "." else ext_str
    else:
        os.makedirs(output_path, exist_ok=True)
        output_path = os.path.join(
            output_path, os.path.basename(input_path)+".xz")

    compress(input_path, output_path)

    # 压缩完成后删除源文件
    if inplace:
        os.remove(input_path)

    return output_path


def compress_file_lzma(input_path, output_path=None, inplace=False):
    """压缩指定文件，返回压缩文件路径"""

    # 检查是否是文件夹
    _input_path = input_path
    if_folder = False
    if os.path.isdir(_input_path):
        # 创建临时的 tar 文件
        if_folder = True
        shutil.make_archive(input_path, 'tar', input_path)
        input_path = _input_path + '.tar'

    def compress_func(input_path, output_path):
        with open(input_path, 'rb') as file_in:
            with lzma.open(output_path, 'wb') as file_out:
                file_out.write(file_in.read())

    xzfile = _compress_file(compress_func, 'xz', input_path,
                            output_path, True if if_folder else inplace)

    if inplace and if_folder:
        os.remove(_input_path)

    return xzfile


def uncompress_file_lzma(input_path, output_path=None, inplace=False):
    """压缩指定文件，返回压缩文件路径"""
    if not input_path.endswith('.xz'):
        return ''

    def uncompress_func(input_path, output_path):

        # 打开压缩文件并解压缩到指定目录
        with lzma.open(input_path, 'rb') as file:
            try:
                # 文件夹
                # 创建 tarfile 对象
                tar = tarfile.open(fileobj=file, mode='r')

                # 解压缩文件到指定目录
                tar.extractall(path=output_path)
                tar.close()
            except:
                # 解压缩文件
                with open(output_path, 'wb') as output_file:
                    content = file.read()
                    output_file.write(content)

    return _uncompress_file(uncompress_func, 'xz', input_path, output_path, inplace)


if __name__ == "__main__":
    ########################################
    # 压缩文件测试
    ########################################
    # res = compress_file_lzma('build')
    # res = compress_file_lzma('TRADE_DATE')
    # res = compress_file_lzma('wechat.py')

    # res = compress_file_lzma('build', 'test')
    # res = compress_file_lzma('TRADE_DATE', 'test')
    # res = compress_file_lzma('wechat.py', 'test')

    # res = uncompress_file_lzma('test/build.tar.xz')
    # res = uncompress_file_lzma('test/TRADE_DATE.xz')
    # res = uncompress_file_lzma('test/wechat.py.xz')

    # res = uncompress_file_lzma('build.tar.xz', 'test2')
    # res = uncompress_file_lzma('TRADE_DATE.xz', 'test2')
    # res = uncompress_file_lzma('wechat.py.xz', 'test2')

    
    pass