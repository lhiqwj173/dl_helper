import sys
import socket
import time
import datetime
import shutil
import os
import traceback
import gzip
import lzma
import tarfile
import zipfile
from joblib import Parallel, delayed

import requests
from bs4 import BeautifulSoup

from loguru import logger
from .wechat import wx


def get(url, headers={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
}):
    # 发起HTTP请求，获取网页内容
    response = requests.get(url, headers=headers)
    content = response.text

    # 解析网页内容
    soup = BeautifulSoup(content, "html.parser")

    return soup


def download(url, file_path, headers={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
}):
    response = requests.get(url, headers=headers)
    # 确保请求成功
    if response.status_code == 200:
        with open(file_path, "wb") as file:
            file.write(response.content)
    else:
        raise Exception(f"文件下载失败: {response}")


def full_cpu_run_different_func(*objs):
    """
    每个 obj 为一个列表, 第一个元素为函数, 后面的元素为函数的参数
    """
    # 并行执行任务
    return Parallel(n_jobs=-1)(delayed(obj[0])(*obj[1:]) for obj in objs)


def full_cpu_run_same_func(func, args):
    """
    按照cpu核心数并行执行任务
    args 为参数列表，每个元素为单次任务的参数(可以是列表)
    """
    # 并行执行任务
    if len(args[0]) > 1:
        # 多个参数
        return Parallel(n_jobs=-1)(delayed(func)(*_args) for _args in args)

    else:
        # 单个参数
        return Parallel(n_jobs=-1)(delayed(func)(_args) for _args in args)


def send_file(file_name):
    # 发送微信
    wechat.wx.send_file(file_name)


def if_trade():
    model_path = wechat.__file__
    trade_date_file = model_path.replace('wechat.py', 'TRADE_DATE')

    today = time.strftime("%Y-%m-%d", time.localtime())
    with open(trade_date_file, 'r')as f:
        trade_dates = f.read().split('\n')
        if today in trade_dates:
            return 1
        else:
            return 0


def next_trade(dt):
    model_path = wechat.__file__
    trade_date_file = model_path.replace('wechat.py', 'TRADE_DATE')

    today = time.strftime("%Y-%m-%d", time.localtime())
    # 2021-01-01 09:30:30
    date = dt[:10]
    with open(trade_date_file, 'r')as f:
        trade_dates = f.read().split('\n')
        trade_dates = [i for i in trade_dates if (i > date and i < today)]

        if trade_dates:
            return int(time.mktime(time.strptime(trade_dates[0], '%Y-%m-%d')))
        else:
            return 0


def init_logger(name, enqueue=False):
    # enqueue : 是否将日志写入队列(多进程)
    # 获取~目录
    home = os.path.expanduser('~')

    # 创建日志目录
    log_dir = os.path.join(home, 'logs')

    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 创建日志文件
    log_file = os.path.join(
        log_dir, f'{name}_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.log')

    logger.remove()  # 先移除默认的日志处理器

    # 添加日志处理器
    logger.add(log_file, enqueue=enqueue, format="{time:YYYY-MM-DD hh:mm:ss} | {message}",
               retention=datetime.timedelta(weeks=1))

    # # 添加控制台处理器
    logger.add(sys.stdout, enqueue=enqueue,
               format="{time:YYYY-MM-DD hh:mm:ss} | {message}")

    # 清理久期文件 7天前的文件
    for file in os.listdir(log_dir):
        file = os.path.join(log_dir, file)
        if os.path.isfile(file):
            if os.path.getmtime(file) < time.time() - 7 * 24 * 60 * 60:
                logger.info(
                    f'清理日志文件: {file}, {datetime.datetime.fromtimestamp(os.path.getmtime(file)).strftime("%Y-%m-%d")}')

                try:
                    os.remove(file)
                except:
                    pass


def _get_caller_info():
    """
    获取调用者的信息
    """
    caller_info = sys._getframe(2)
    return caller_info.f_code.co_filename.split('\\')[-1], caller_info.f_code.co_name, str(caller_info.f_lineno)


def log(*msg):
    msg = [str(i) for i in msg]
    msg = ':'.join(_get_caller_info()) + " - " + ' '.join(msg)
    logger.info(msg)

##################################################################
# 异常捕捉
##################################################################


def unhandled_exception(exc_type, exc_value, exc_traceback):
    # 排除 KeyboardInterrupt
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return

    wx.send_message(f'异常捕捉\n{exc_type}\n{exc_value}')

    msg = traceback.format_exception(exc_type, exc_value, exc_traceback)
    for m in msg:
        log(m)


# 设置异常处理钩子
sys.excepthook = unhandled_exception

##################################################################
# 异常捕捉
##################################################################


def unzip(filepath, output_dir):
    zip_file = zipfile.ZipFile(filepath)
    zip_list = zip_file.namelist()

    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    for f in zip_list:
        try:
            nf = f.encode('cp437').decode('gbk')
        except:
            nf = f.encode('utf-8').decode('utf-8')
        new_path = os.path.join(output_dir, nf)
        # 判断f是否是目录，目录的结尾是'/'或'\'
        if f[-1] not in ['\\', '/']:
            with open(new_path, 'wb') as file:
                file.write(zip_file.read(f))
                file.close()
        else:
            os.mkdir(new_path)
    zip_file.close()


def _uncompress_file(uncompress, ext_str, input_path, output_path, inplace):
    """解压文件"""
    ext_str = ext_str.replace(".", "")
    folder_ext = f'.tar.{ext_str}'

    if None is output_path:
        # 指定解压缩文件夹
        output_path = os.path.dirname(input_path)

        # 如果是文件夹 解压缩目录为文件名称
        if input_path.endswith(folder_ext):
            output_path = input_path[:-len(folder_ext)]
            os.makedirs(output_path, exist_ok=True)

    else:
        # 确保文件夹存在
        os.makedirs(output_path, exist_ok=True)

    # 如果是压缩文件为单文件 输出路径增加文件名称
    if not input_path.endswith(folder_ext):
        output_path = os.path.join(output_path, os.path.basename(
            input_path)[:-len(f'.{ext_str}')])

    uncompress(input_path, output_path)

    # 解压完成后删除源文件
    if inplace:
        os.remove(input_path)

    return output_path


def _compress_file(compress, ext_str, input_path, output_path, inplace):
    """压缩文件"""
    if None is output_path:
        # 替换后缀
        output_path = input_path + \
            f".{ext_str}" if ext_str[0] != "." else ext_str
    else:
        os.makedirs(output_path, exist_ok=True)
        output_path = os.path.join(
            output_path, os.path.basename(input_path)+".xz")

    compress(input_path, output_path)

    # 压缩完成后删除源文件
    if inplace:
        os.remove(input_path)

    return output_path


def compress_file_lzma(input_path, output_path=None, inplace=False):
    """压缩指定文件，返回压缩文件路径"""

    # 检查是否是文件夹
    _input_path = input_path
    if_folder = False
    if os.path.isdir(_input_path):
        # 创建临时的 tar 文件
        if_folder = True
        shutil.make_archive(input_path, 'tar', input_path)
        input_path = _input_path + '.tar'

    def compress_func(input_path, output_path):
        with open(input_path, 'rb') as file_in:
            with lzma.open(output_path, 'wb') as file_out:
                file_out.write(file_in.read())

    xzfile = _compress_file(compress_func, 'xz', input_path,
                            output_path, True if if_folder else inplace)

    if inplace and if_folder:
        os.remove(_input_path)

    return xzfile


def uncompress_file_lzma(input_path, output_path=None, inplace=False):
    """压缩指定文件，返回压缩文件路径"""
    if not input_path.endswith('.xz'):
        return ''

    def uncompress_func(input_path, output_path):

        # 打开压缩文件并解压缩到指定目录
        with lzma.open(input_path, 'rb') as file:
            try:
                # 文件夹
                # 创建 tarfile 对象
                tar = tarfile.open(fileobj=file, mode='r')

                # 解压缩文件到指定目录
                tar.extractall(path=output_path)
                tar.close()
            except:
                # 解压缩文件
                with open(output_path, 'wb') as output_file:
                    content = file.read()
                    output_file.write(content)

    return _uncompress_file(uncompress_func, 'xz', input_path, output_path, inplace)


if __name__ == "__main__":
    ########################################
    # 压缩文件测试
    ########################################
    # res = compress_file_lzma('build')
    # res = compress_file_lzma('TRADE_DATE')
    # res = compress_file_lzma('wechat.py')

    # res = compress_file_lzma('build', 'test')
    # res = compress_file_lzma('TRADE_DATE', 'test')
    # res = compress_file_lzma('wechat.py', 'test')

    # res = uncompress_file_lzma('test/build.tar.xz')
    # res = uncompress_file_lzma('test/TRADE_DATE.xz')
    # res = uncompress_file_lzma('test/wechat.py.xz')

    # res = uncompress_file_lzma('build.tar.xz', 'test2')
    # res = uncompress_file_lzma('TRADE_DATE.xz', 'test2')
    # res = uncompress_file_lzma('wechat.py.xz', 'test2')

    pass
