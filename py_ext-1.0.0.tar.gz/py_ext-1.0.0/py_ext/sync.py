"""
同步远程服务器文件
"""
import paramiko
import os

from .tool import compress_file_lzma, uncompress_file_lzma

# 上传文件的本地路径和远程路径
LOCAL_FOLDER = ''
REMOTE_FOLDER = '/root/sync_data/'


def _sync_file(hostname, port, username, password, sync_code=None):
    # 创建 SSH 客户端
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # 连接到远程服务器
    client.connect(hostname, port, username, password)

    # 创建 SFTP 客户端
    sftp = client.open_sftp()

    if sync_code is not None:
        sync_code(sftp)

    # 关闭 SFTP 客户端和 SSH 客户端
    if sftp:
        sftp.close()
    if client:
        client.close()


def upload(file, hostname, port, username, password, compress=True):
    """上传文件到远程服务器 remote_folder"""
    file = os.path.join(LOCAL_FOLDER, file)

    if compress:
        file = compress_file_lzma(file, inplace=False)

    def sync_code(sftp):
        sftp.put(file, os.path.join(
            REMOTE_FOLDER, os.path.basename(file)))

    _sync_file(hostname, port, username, password, sync_code)

    if compress:
        os.remove(file)


def download(remote_file, hostname, port, username, password, compress=True):
    """从远程服务器下载文件到本地 local_folder"""
    local_path = os.path.join(
        LOCAL_FOLDER, os.path.basename(remote_file))

    def sync_code(sftp):
        sftp.get(os.path.join(REMOTE_FOLDER, remote_file), local_path)

    _sync_file(hostname, port, username, password, sync_code)

    if compress:
        uncompress_file_lzma(local_path, inplace=True)


if __name__ == "__main__":
    # # 上传文件
    # upload('wechat.py', '146.56.155.29', 22, 'root', 'LHss6632673')
    # upload(r"D:\code\featrue_data\data\raw_data\data_20240102",
    #        '146.56.155.29', 22, 'root', 'LHss6632673')

    # # 下载文件
    # download('wechat2.py.xz', '146.56.155.29', 22, 'root', 'LHss6632673')
    # download('build2.tar.xz', '146.56.155.29', 22, 'root', 'LHss6632673')

    pass
