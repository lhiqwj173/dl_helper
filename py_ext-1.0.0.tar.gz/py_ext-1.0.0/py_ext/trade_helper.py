"""
交易相关的扩展
"""
import datetime
import time
import os


####################################
# 常量定义
####################################
# 交易时间
DT_TRADE_INIT, DT_PRE_OPEN, DT_PRE_REST, DT_OPEN, DT_REST, DT_REOPEN, DT_PRE_CLOSE, DT_CLOSE = [int(time.mktime(time.strptime(
    f'{time.strftime("%Y-%m-%d", time.localtime())} {i}:00', '%Y-%m-%d %H:%M:%S'))) for i in ['9:00', '9:15', '9:25', '9:30', '11:30', '13:00', '14:57', '15:00']]
DTS = [DT_TRADE_INIT, DT_PRE_OPEN, DT_PRE_REST,
       DT_OPEN, DT_REST, DT_REOPEN, DT_PRE_CLOSE, DT_CLOSE]
# 时间名称
STATUS_NAME = ['等待开盘', '开盘竞价', '开盘准备',
               '上午开盘', '中午休市', '下午开盘', '收盘竞价', '当天收盘']
STA_WAIT, STA_PRE_OPEN, STA_PRE_REST, STA_OPEN, STA_REST, STA_REOPEN, STA_PRE_CLOSE, STA_CLOSE = range(
    len(STATUS_NAME))

####################################
# 常量定义
####################################


def _is_weekend(date):
    """
    判断是否是周末
    """
    if isinstance(date, str):
        date = datetime.datetime.strptime(date, '%Y-%m-%d')

    return date.weekday() in [5, 6]


def _get_no_trade_date():
    """返回非交易日字符串列表
    可在 https://www.tdx.com.cn/url/holiday/ 中更新
    """
    no_trade_date_str = """日期	星期	节日	休市地区及市场
    2023.10.02	星期一	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2023.10.03	星期二	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2023.10.04	星期三	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2023.10.05	星期四	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2023.10.06	星期五	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.01.01	星期一	元旦	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.12	星期一	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.13	星期二	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.14	星期三	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.15	星期四	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.16	星期五	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.04.04	星期四	清明节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.04.05	星期五	清明节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.05.01	星期三	劳动节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.05.02	星期四	劳动节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.05.03	星期五	劳动节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.06.10	星期一	端午节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.09.16	星期一	中秋节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.09.17	星期二	中秋节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.01	星期二	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.02	星期三	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.03	星期四	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.04	星期五	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.07	星期一	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.01.01	星期一	元旦	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.09	星期五	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.12	星期一	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.13	星期二	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.14	星期三	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.15	星期四	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.02.16	星期五	春节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.04.04	星期四	清明节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.04.05	星期五	清明节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.05.01	星期三	劳动节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.05.02	星期四	劳动节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.05.03	星期五	劳动节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.06.10	星期一	端午节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.09.16	星期一	中秋节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.09.17	星期二	中秋节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.01	星期二	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.02	星期三	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.03	星期四	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.04	星期五	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所
    2024.10.07	星期一	国庆节	深圳市场、上海市场、上期所、上海黄金、大连商品、郑州商品、中金所、渤海商品、广期所"""

    data = no_trade_date_str.split('\n')[1:]
    data = [i.split('\t')[0].replace(r'.', '-') for i in data]

    return data


def if_trade_date(date=''):
    """
    判断是否是交易日
    :param date: 日期
    :return: True or False
    """
    if not date:
        date = time.strftime("%Y-%m-%d", time.localtime())

    # 周末不交易
    if _is_weekend(date):
        return False

    # 节假日不交易
    if date in _get_no_trade_date():
        return False

    return True


def _get_trade_date():
    """
    读取交易日列表
    """
    # 获取用户目录
    user_path = os.path.expanduser('~')

    # 交易日文件
    trade_date_file = os.path.join(user_path, 'TRADE_DATE')

    if not os.path.exists(trade_date_file):
        msg = '请在用户目录下创建 TRADE_DATE 文件'
        from .wechat import send_wx
        send_wx(msg)
        raise Exception(msg)

    with open(trade_date_file, 'r')as f:
        dates = f.read().split('\n')
        return dates


def _get_trade_shift_date(date='', n=1):
    """
    返回date前后第n个交易日
    n > 0 前n个交易日
    n < 0 后n个交易日
    """
    dates = _get_trade_date()

    if not date:
        date = time.strftime("%Y-%m-%d", time.localtime())

    if date not in dates:
        dates.append(date)
        dates.sort()

    index = dates.index(date)
    if 0 <= index - n < len(dates):
        return dates[index - n]


def pre_trade_date(date='', n=1):
    """
    返回date前第n个交易日
    n>0 
    """
    return _get_trade_shift_date(date, n)


def next_trade_date(date='', n=1):
    """
    返回date后第n个交易日
    n>0 
    """
    return _get_trade_shift_date(date, -n)


def get_state_name(sta):
    """返回状态名称"""
    return STATUS_NAME[sta]


def trade_time_status(ahead=0):
    """
    更新并返回当前状态

    STA_WAIT, STA_PRE_OPEN, STA_PRE_REST, STA_OPEN, STA_REST, STA_REOPEN, STA_PRE_CLOSE, STA_CLOSE
    '等待开盘', '开盘竞价', '开盘准备', '上午开盘', '中午休市', '下午开盘', '收盘竞价', '当天收盘'

    ahead : 提前的秒数, 若为负数则延后
    """
    # 当前时间
    now = time.localtime()

    # 当前日期
    date = time.strftime("%Y-%m-%d", now)

    # 非交易日返回 当天收盘
    if not if_trade_date(date):
        return STA_CLOSE

    # 当前时间戳
    timestamp = time.mktime(now) + ahead
    if timestamp < DT_TRADE_INIT:
        return STA_WAIT

    elif timestamp <= DT_PRE_REST:
        return STA_PRE_OPEN

    elif timestamp <= DT_OPEN:
        return STA_PRE_REST

    elif timestamp <= DT_REST:
        return STA_OPEN

    elif timestamp <= DT_REOPEN:
        return STA_REST

    elif timestamp <= DT_PRE_CLOSE:
        return STA_REOPEN

    elif timestamp <= DT_CLOSE:
        return STA_PRE_CLOSE

    else:
        return STA_CLOSE


def next_trade_DT(sta, ahead=0):
    """
    返回当前状态下一个时间点

    ahead : 提前的秒数, 若为负数则延后
    """
    if sta == len(DTS):
        return None

    return DTS[sta] - ahead
