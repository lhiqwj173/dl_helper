import requests
import time
import json
import sys
import socket


class WeChat:
    def __init__(self):
        """
        配置初始信息
        """
        self.CORPID = "wwbdf90f755eadc2b3"  # 企业ID
        self.CORPSECRET = "NFf11bf7u7UjJdw-_YsdqKwU4bBlIAscn976GRQQwEc"  # 应用Secret
        self.AGENTID = "1000002"  # 应用Agentid
        self.TOUSER = "@all"  # 接收消息的userid

        self.ACCESS_TOKEN = ""
        self.TOKEN_TIME = 0

    def _get_access_token(self):
        """
        调用接口返回登录信息access_token
        """
        url = f"https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={self.CORPID}&corpsecret={self.CORPSECRET}"
        res = requests.get(url=url)
        return json.loads(res.text)["access_token"]

    def get_access_token(self):
        cur_time = time.time()
        if 0 < cur_time - self.TOKEN_TIME < 7200:
            return self.ACCESS_TOKEN
        else:
            self.TOKEN_TIME = cur_time
            self.ACCESS_TOKEN = self._get_access_token()
            return self.ACCESS_TOKEN

    def send_message(self, message):
        """
        发送文本消息
        """
        # 获取host name
        hostname = socket.gethostname()
        message = f"[{hostname}] {message}"

        url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={self.get_access_token()}"
        send_values = {
            "touser": self.TOUSER,
            "msgtype": "text",
            "agentid": self.AGENTID,
            "text": {"content": message},
        }
        send_message = bytes(json.dumps(send_values), "utf-8")
        res = requests.post(url, send_message)
        return res.json()["errmsg"]

    def _upload_file(self, file):
        """
        先将文件上传到临时媒体库
        """
        url = f"https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token={self.get_access_token()}&type=file"
        data = {"file": open(file, "rb")}
        res = requests.post(url, files=data)
        return res.json()["media_id"]

    def send_file(self, file):
        """
        发送文件
        """
        media_id = self._upload_file(file)  # 先将文件上传至临时媒体库
        url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={self.get_access_token()}"
        send_values = {
            "touser": self.TOUSER,
            "msgtype": "file",
            "agentid": self.AGENTID,
            "file": {"media_id": media_id},
        }
        send_message = bytes(json.dumps(send_values), "utf-8")
        res = requests.post(url, send_message)
        return res.json()["errmsg"]


wx = WeChat()


def send_wx(msg):
    wx.send_message(msg)


if __name__ == "__main__":
    args = sys.argv
    if len(args) > 1:
        message = args[1]
        wx.send_message(message)
