import pandas as pd
import time
import datetime
import requests

from .wechat import wx


def select_time(_type: str = "sh000902"):
    """
    择时接口
    _type:择时类型
        SH000902: 使用中证流通20日涨跌幅进行择时

    返回:
        1: 持仓
        0: 空仓
    """
    if _type.lower() == 'sh000902':
        return sh000902_select_time()
    else:
        return 0


def sh000902_select_time():
    # 使用中证流通20日涨跌幅进行择时

    # https://stock.xueqiu.com/v5/stock/chart/kline.json?symbol=SH000902&begin=1670755221276&period=day&type=before&count=-284
    # 构造url
    # 请求数量
    code = 'sh000902'
    n = 100
    # 时间戳
    timestamp = int(round(time.time() * 1000))
    # 数量
    count = -n
    # url
    url = f'https://stock.xueqiu.com/v5/stock/chart/kline.json?symbol={code.upper()}&begin={str(timestamp)}&period=day&type=before&count={str(count)}'

    # 请求头
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'}

    # 获取雪球 cookie
    url_0 = 'https://xueqiu.com/hq'
    r = requests.get(url_0, headers=headers)
    r.encoding = "utf-8"
    cookiedict = requests.utils.dict_from_cookiejar(r.cookies)

    cookies = {'xq_a_token': cookiedict['xq_a_token']}
    r = requests.get(url, headers=headers, cookies=cookies)
    r.encoding = "utf-8"

    # 检查是否正确获取数据
    if r.json()['error_code'] != 0:
        wx.send_message("[宽基择时] 中证流通历史数据获取失败, 请检查")
        return 0

    # 计算 20日涨跌幅
    data = pd.DataFrame(r.json()['data']['item'],
                        columns=r.json()['data']['column'])

    # 删除当天的数据
    dt = str(datetime.date.today())
    timeArray = time.strptime(dt, "%Y-%m-%d")
    timestamp = int(time.mktime(timeArray) * 1000)
    data = data.loc[data['timestamp']!=timestamp,:]

    if data['close'][len(data)-1]/data['close'][len(data)-21] - 1 > 0:
        return 1
    else:
        return 0


if "__main__" == __name__:
    print(select_time())
