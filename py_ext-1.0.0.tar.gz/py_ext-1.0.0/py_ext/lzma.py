"""
调用7z压缩/解压文件
替换原文件夹

C:/Windows/7z.exe | /usr/bin/7z

压缩:   1. 7z a -mx<level> filepath.temp filepath(level: 0-9)
        2. del filepath
        3. rename filepath.temp > filepath

解压:   1. filename, folder < filepath
        2. 7z e filepath -ofolder/temp
        3. del filepath
        4. rename folder/temp/filename > filepath
"""

import os
import subprocess
import shutil
import platform

# C:/Windows/7z.exe | /usr/bin/7z
file7z = ''
if platform.system() == 'Windows':
    file7z = 'C:/Windows/7z.exe'
else:
    file7z = '/usr/bin/7z'


def decompress(filepath, outfolder='temp', delete=True):
    """
    解压缩文件，会替换原文件
    """
    folder, filename = os.path.split(filepath)
    tempfolder = folder + f'/{outfolder}'

    if os.path.exists(tempfolder):
        # 清空文件夹内的文件
        for filename in os.listdir(tempfolder):
            file_path = os.path.join(tempfolder, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
            else:
                shutil.rmtree(file_path)
    else:
        os.makedirs(tempfolder)

    cmd = file7z + f' x "{filepath}" -o"{tempfolder}"'
    subprocess.call(cmd, shell=True, stdout=subprocess.DEVNULL)

    if delete:
        if filepath[-4:] == '.001':
            base_file_name = os.path.split(filepath)[-1][:-4]
            to_del_list = []
            for i in os.listdir(folder):
                if i[:-4] == base_file_name:
                    to_del_list.append(os.path.join(folder, i))
            for file in to_del_list:
                os.remove(file)
        else:
            os.remove(filepath)

    # 删除临时文件夹
    if outfolder == 'temp':
        # 移出文件
        for file in os.listdir(tempfolder):
            os.rename(tempfolder + '/' + file, folder + '/' + file)

        shutil.rmtree(tempfolder)


def check_compress_success(compressfile, max_size):

    # 检查是否压缩成功
    if not os.path.exists(compressfile if None is max_size else compressfile+'.001'):
        return False

    if not None is max_size and not os.path.exists(compressfile+'.002'):
        # 没有分文件，重命名
        os.rename(compressfile+'.001', compressfile)

    return True


def compress(filepath, level=5, delete=True, max_size=None):
    """
    压缩文件，会替换原文件
    """
    tempfilepath = filepath + '.7z'

    cmd = file7z + ' a -mx' + str(level) + ' '
    if max_size:
        cmd += f'-v{max_size.lower()} '
    cmd += f'"{tempfilepath}" "{filepath}"'
    subprocess.call(cmd, shell=True, stdout=subprocess.DEVNULL)

    # 检查是否压缩成功
    check_compress_success(tempfilepath, max_size)

    if delete:
        os.remove(filepath)

    return True


def compress_files(file_list, outpath, level=5, delete=True, max_size=None):
    """
    压缩文件列表
    """
    cmd = file7z + ' a -mx' + str(level) + ' '
    if max_size:
        cmd += f'-v{max_size.lower()} '
    cmd += f'"{outpath}"'
    for i in file_list:
        cmd += f' "{i}"'
    subprocess.call(cmd, shell=True, stdout=subprocess.DEVNULL)

    # 检查是否压缩成功
    check_compress_success(outpath, max_size)

    # 删除原文件
    if delete:
        for file in file_list:
            os.remove(file)

    return True


def compress_folder(folderpath, outpath, level=5, inplace=True, max_size=None):
    """
    压缩文件夹
    """
    cmd = file7z + ' a -mx' + str(level) + ' '
    if max_size:
        cmd += f'-v{max_size.lower()} '
    cmd += f'"{outpath}" "{folderpath}"'
    subprocess.call(cmd, shell=True, stdout=subprocess.DEVNULL)

    # 检查是否压缩成功
    check_compress_success(outpath, max_size)

    # 删除文件夹
    if inplace:
        shutil.rmtree(folderpath)

    return True


if __name__ == '__main__':
    # folder = r"C:\Users\lh\Desktop\temp\binctabl_p10_v1_nostop"
    # compress_folder(folder, folder+".7z", 9)

    # compress(r"D:\code\featrue_data\binance_datas\test.csv", 9)

    # decompress(r"C:\Users\lh\Downloads\trade_1718251200025")

    # file_path = r"C:\Users\lh\Downloads\binctabl_10_target_5_period_point_v0_TPU.7z"
    # decompress(file_path, 'decompress_temp')

    # file_path = r"D:\telegram download\test\t.mp4"
    # compress(file_path, delete=False, max_size='500M')

    # file_path = r"D:\telegram download\test\t.mp4"
    # file_path2 = r"D:\telegram download\test\t2.mp4"
    # compress_files([file_path, file_path2],
    #                r"D:\telegram download\test\t.7z", delete=False, max_size='50M')

    # file_path = r"D:\telegram download\test"
    # out_path = r"D:\telegram download\test.7z"
    # compress_folder(file_path, out_path, inplace=False, max_size='50M')

    file_path = r"D:\telegram download\test\t.7z.001"
    decompress(file_path, delete=True)
