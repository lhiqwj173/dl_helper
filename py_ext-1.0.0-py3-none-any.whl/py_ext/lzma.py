"""
调用7z压缩/解压文件
替换原文件夹

C:/Windows/7z.exe | /usr/bin/7z

压缩:   1. 7z a -mx<level> filepath.temp filepath(level: 0-9)
        2. del filepath
        3. rename filepath.temp > filepath

解压:   1. filename, folder < filepath
        2. 7z e filepath -ofolder/temp
        3. del filepath
        4. rename folder/temp/filename > filepath
"""

import os
import subprocess
import shutil
import platform

# C:/Windows/7z.exe | /usr/bin/7z
file7z = ''
if platform.system() == 'Windows':
    file7z = 'C:/Windows/7z.exe'
else:
    file7z = '/usr/bin/7z'

def decompress(filepath, outfolder='temp'):
    """
    解压缩文件，会替换原文件
    """
    folder, filename = os.path.split(filepath)
    tempfolder = folder + f'/{outfolder}'

    if os.path.exists(tempfolder):
        # 清空文件夹内的文件
        for filename in os.listdir(tempfolder):
            file_path = os.path.join(tempfolder, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
            else:
                shutil.rmtree(file_path)
    else:
        os.makedirs(tempfolder)

    cmd = file7z + ' x ' + filepath + ' -o' + tempfolder
    subprocess.call(cmd, shell=True)

    os.remove(filepath)

    # 删除临时文件夹
    if outfolder == 'temp':
        # 移出文件
        for file in os.listdir(tempfolder):
            os.rename(tempfolder + '/' + file, folder + '/' + file)

        shutil.rmtree(tempfolder)


def compress(filepath, level=5):
    """
    压缩文件，会替换原文件
    """
    tempfilepath = filepath + '.7z'

    cmd = file7z + ' a -mx' + str(level) + ' ' + tempfilepath + ' ' + filepath
    subprocess.call(cmd, shell=True)

    # 检查是否解压成功
    if not os.path.exists(tempfilepath):
        return False

    os.remove(filepath)
    return True


def compress_files(file_list, outpath, level=5):
    """
    压缩文件列表
    """
    cmd = file7z + ' a -mx' + str(level) + ' ' + \
        outpath + ' ' + ' '.join(file_list)
    subprocess.call(cmd, shell=True)

    if not os.path.exists(outpath):
        return False

    # 删除原文件
    for file in file_list:
        os.remove(file)

    return True


def compress_folder(folderpath, outpath, level=5, inplace=True):
    """
    压缩文件夹
    """
    cmd = file7z + ' a -mx' + str(level) + ' ' + \
        outpath + ' ' + folderpath
    subprocess.call(cmd, shell=True)

    if not os.path.exists(outpath):
        return False

    # 删除文件夹
    if inplace:
        shutil.rmtree(folderpath)

    return True


if __name__ == '__main__':
    # folder = r"C:\Users\lh\Desktop\temp\binctabl_p10_v1_nostop"
    # compress_folder(folder, folder+".7z", 9)

    # compress(r"D:\code\featrue_data\binance_datas\test.csv", 9)

    # decompress(r"C:\Users\lh\Downloads\trade_1718251200025")

    file_path = r"C:\Users\lh\Downloads\trade_1718251200025"
    decompress(file_path, 'decompress_temp')

    # 移出文件
    folder, file_name = os.path.split(file_path)
    temp_file = os.path.join(folder, 'decompress_temp', 'data', file_name)
    os.rename(temp_file, file_path)
