"""
调用7z压缩/解压文件
替换原文件夹

C:/Windows/7z.exe | /usr/bin/7z

压缩:   1. 7z a -mx<level> filepath.temp filepath(level: 0-9)
        2. del filepath
        3. rename filepath.temp > filepath

解压:   1. filename, folder < filepath
        2. 7z e filepath -ofolder/temp
        3. del filepath
        4. rename folder/temp/filename > filepath
"""

import os
import subprocess
import shutil
import platform

system = platform.system()

# C:/Windows/7z.exe | /usr/bin/7z
file7z = ''
if system == 'Windows':
    file7z = 'C:/Windows/7z.exe'
else:
    file7z = '/usr/bin/7z'
    if not os.path.exists(file7z):
        # 安装 7z
        cmd = 'apt-get install p7zip'
        subprocess.call(cmd, shell=True)


def listdir_compress_file(filepath, path=''):
    """
    读取压缩文件path下 文件列表
    path 不指定则递归返回所有列表
    """
    path = path.replace('\\', '/')
    level = path.count('/') if path else 100

    cmd = file7z + ' l "' + filepath + '" -sccUTF-8'
    result = subprocess.run(
        cmd, capture_output=True, text=True, shell=True)
    if None is result.stdout:
        cmd = file7z + ' l "' + filepath + '"'
        result = subprocess.run(
            cmd, capture_output=True, text=True, shell=True)

    rets = []
    begin = False
    end = False
    for i in result.stdout.strip().split('\n'):
        items = [i.strip() for i in i.split(' ')]
        items = [i for i in items if i]

        if '-------------------' in i:
            if not begin:
                begin = True
                continue
            else:
                end = True
                break

        if not begin:
            continue

        # 匹配
        _path = '/' + items[-1].replace('\\', '/')

        if path:
            _level = _path.count('/')
            if _level < level:
                continue
            elif _level > level:
                continue
            elif not _path.startswith(path):
                continue

        if items[3] == '0':
            # 文件夹
            _path += '/'

        rets.append(_path)

    return rets


def decompress_part(filepath, path, outfolder):
    """部分解压"""
    path = path.replace('/', '\\')

    if path[-1] == '\\':
        path = path[:-1]
    if path[0] == '\\':
        path = path[1:]

    if not os.path.exists(outfolder):
        os.makedirs(outfolder)

    cmd = file7z + ' x "' + filepath + f'" {path} -o{outfolder}'
    result = subprocess.run(cmd, capture_output=True, text=True, shell=True)


def decompress(filepath, outfolder='temp', inplace=True):
    """
    解压缩文件，会替换原文件
    """
    folder, filename = os.path.split(filepath)
    tempfolder = folder + f'/{outfolder}'
    if not os.path.exists(folder):
        os.makedirs(folder)

    cmd = file7z + ' x ' + filepath + ' -o' + tempfolder
    subprocess.call(cmd, shell=True)

    if inplace:
        os.remove(filepath)

    # 删除临时文件夹
    if outfolder == 'temp':
        # 移出文件
        for file in os.listdir(tempfolder):
            os.rename(tempfolder + '/' + file, folder + '/' + file)

        shutil.rmtree(tempfolder)


def compress(filepath, level=5):
    """
    压缩文件，会替换原文件
    """
    tempfilepath = filepath + '.temp'

    cmd = file7z + ' a -mx' + str(level) + ' ' + tempfilepath + ' ' + filepath
    subprocess.call(cmd, shell=True)

    # 检查是否解压成功
    if not os.path.exists(tempfilepath):
        return False

    os.remove(filepath)
    os.rename(tempfilepath, filepath)
    return True


def compress_files(file_list, outpath, level=5):
    """
    压缩文件列表
    """
    cmd = file7z + ' a -mx' + str(level) + ' ' + \
        outpath + ' ' + ' '.join(file_list)
    subprocess.call(cmd, shell=True)

    if not os.path.exists(outpath):
        return False

    # 删除原文件
    for file in file_list:
        os.remove(file)

    return True


def compress_folder(folderpath, outpath, level=5, inplace=True):
    """
    压缩文件夹
    """
    cmd = file7z + ' a -mx' + str(level) + ' ' + \
        outpath + ' ' + folderpath
    subprocess.call(cmd, shell=True)

    if not os.path.exists(outpath):
        return False

    # 删除文件夹
    if inplace:
        shutil.rmtree(folderpath)

    return True


if __name__ == '__main__':
    # folder = r"C:\Users\lh\Desktop\temp\159856"
    # compress_folder(folder, folder+".7z", 9)

    res = listdir_compress_file(
        r"Z:\L2_DATA\his_data\20231017.7z", '/20231017/')
    print(res)
