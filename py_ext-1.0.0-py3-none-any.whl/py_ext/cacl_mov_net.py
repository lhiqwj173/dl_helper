import time, requests, datetime
import pandas as pd
from .wechat import wx

def mov_net(all_data_map, mov_n):
    """
    all_data_map: 
    {
    "code1": pd.DataFrame,
    "code2": pd.DataFrame,
    }
    
    mov_n: 动量周期
    """
    codes = [code for code in all_data_map]
    
    # 拼接数据
    datas = [all_data_map[i][['close']] for i in codes] + [all_data_map[i][['open']] for i in codes]
    data = pd.concat(datas, axis=1)
    data.columns = [f'{code}_close' for code in codes] + [f'{code}_open' for code in codes]

    # nan值向后填充
    data.fillna(method='ffill', inplace=True)
    data.dropna(inplace=True)

    # 计算动量涨幅
    for code in codes:
        data[f'{code}_rets'] =  data[f'{code}_close'].pct_change()
        data[f'{code}_mov'] =  data[f'{code}_close']/(data[f'{code}_close'].shift(mov_n)) - 1

    # 最大收益率
    data['max_mov'] = data[[f'{code}_mov' for code in codes]].max(axis=1)
    # 信号
    for code in codes:
        data[f'{code}_signal'] = data[f'{code}_mov'] == data['max_mov']
        data[f'{code}_signal'] = data[f'{code}_signal'].map(lambda x:1 if x else 0)

    # 真实信号
    for code in codes:
        data[f'{code}_signal_real'] = data[f'{code}_signal'].shift(1)

    # 换仓信号
    for code in codes:
        data[f'{code}_first_in'] = data[f'{code}_signal_real'].diff()
        data[f'{code}_first_in'] = data[f'{code}_first_in'].map(lambda x: 1 if x==1 else 0)

    #  隔日收益率
    for code in codes:
        data[f'{code}_rets_next_day'] = data[f'{code}_open']/(data[f'{code}_close'].shift())-1

    #  修正日收益率
    for code in codes:
        data[f'{code}_rets_fix'] = data[f'{code}_rets']
        data.loc[data[f'{code}_first_in']==1, f'{code}_rets_fix'] = (data.loc[data[f'{code}_first_in']==1,f'{code}_rets']+1)/(data.loc[data[f'{code}_first_in']==1,f'{code}_rets_next_day']+1)-1

    #  交易费用
    fee_rate = 0.0005
    data[f'fee'] = 0
    for code in codes:
        data[f'fee'] = data[f'fee'] + data[f'{code}_first_in']*2*fee_rate

    # 收益
    data[f'rets'] = 0
    for code in codes:
        data[f'rets'] = data[f'rets'] + data[f'{code}_rets_fix']*data[f'{code}_signal_real']
        
    data[f'rets'] = data[f'rets'] - data['fee']

    # 净值
    data.dropna(inplace=True)
    data[f'net'] = (data[f'rets']+1).cumprod()

    return data[[f'net']]

cookies = {}
def get_data_xueqiu(code, n):
    # https://stock.xueqiu.com/v5/stock/chart/kline.json?symbol=SH000902&begin=1670755221276&period=day&type=before&count=-284
    # 构造url
    # code: 带市场前缀
    # n: 请求数量
    global cookies
    
    # 时间戳
    timestamp = int(round(time.time() * 1000))
    # 数量
    count = -(n + 1)
    # url
    url = f'https://stock.xueqiu.com/v5/stock/chart/kline.json?symbol={code.upper()}&begin={str(timestamp)}&period=day&type=before&count={str(count)}'

    # 请求头
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'}

    # 检查 获取雪球 cookie
    if not cookies:
        url_0 = 'https://xueqiu.com/hq'
        r = requests.get(url_0, headers=headers)
        r.encoding = "utf-8"
        cookiedict = requests.utils.dict_from_cookiejar(r.cookies)
        cookies = {'xq_a_token': cookiedict['xq_a_token']}
        
    r = requests.get(url, headers=headers, cookies=cookies)
    r.encoding = "utf-8"

    # 检查是否正确获取数据
    if r.json()['error_code'] != 0:
        return

    # 返回数据
    data = pd.DataFrame(r.json()['data']['item'],
                        columns=r.json()['data']['column'])
    
    # 格式化时间
    data['datetime'] = pd.to_datetime(data['timestamp'], origin='1970-01-01 08:00:00', unit='ms')
    
    # 删除未完成的当天数据
    dt = str(datetime.date.today())
    if str(datetime.datetime.now())[:19] > dt + " 15:01:00":
        timeArray = time.strptime(dt, "%Y-%m-%d")
        timestamp = int(time.mktime(timeArray) * 1000)
        data = data.loc[data['timestamp']!=timestamp,:].set_index('datetime')
    else:
        data = data.iloc[1:,:].set_index('datetime')
    
    # 添加code
    data['code'] = code    
    
    return data


def calc_freq_mov_net(codes=[], mov_ns=[]):
    """返回最有参数 int """
    all_data_map = {}
    for code in codes:
        all_data_map[code] = get_data_xueqiu(code, 1000)

    # 动量周期
    if not mov_ns:
        mov_ns = [(i+1)*5 for i in range(7)]

    # 单个周期动量净值
    nets = []
    for i in mov_ns:
        nets.append(mov_net(all_data_map, i))

    nets_df = pd.concat(nets,axis=1).dropna()
    nets_df.columns = [str(i) for i in mov_ns]
    # 统一起始
    n = 15
    nets_df = nets_df.iloc[len(nets_df) - n:,:]
    for i in mov_ns:
        nets_df[str(i)] = nets_df[str(i)] / nets_df[str(i)][0]

    # 对比取最大值
    latest_nets = nets_df.iloc[len(nets_df)-1].to_list()
    max_net = max(latest_nets)
    max_n = list(nets_df)[latest_nets.index(max_net)]

    # 发送净值图像
    file_name = f'.\\movs_net_{time.strftime("%Y%m%d", time.localtime())}.jpg'
    ax=nets_df.plot(figsize=(10,5))
    fig=ax.get_figure()
    fig.savefig(file_name)
    # 发送微信
    wx.send_file(file_name)

    return int(max_n)

def calc_freq_mov_net_for_cpp(codes_str):
    codes = codes_str.split(',')
    return calc_freq_mov_net(codes)

if __name__=="__main__":
    #calc_freq_mov_net(['sh512100', 'sh510300', 'sz159949'])
    calc_freq_mov_net_for_cpp('sh512100,sh510300,sz159949')